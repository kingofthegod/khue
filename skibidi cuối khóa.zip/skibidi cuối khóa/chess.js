/* chess.js — optimized version (readable + moderately compact)
   Features:
   - Move generation for all pieces
   - Promotion handling (Q/R/N/B)
   - Check / Checkmate / Stalemate
   - Minimax + alpha-beta
   - Simple eval: material + mobility + center control + basic king safety
   - Elo persist & update (+5 win, +1 draw)
   - Time controls & clocks (normal/blitz/hyper)
   - Move list, undo limit (3), promotion modal
*/

/* ===========================
   State & DOM references
   =========================== */
const state = {
  board: [], whiteToMove: true, history: [], selected: null, legalMoves: [],
  playing: false, playerColor: 'white', aiColor: 'black', depth: 2,
  playerElo: 800, botElo: 1000, timeControl: 'none', playerClock: 0, botClock: 0,
  clockInterval: null, movesSAN: [], undoLeft: 3
};

const boardEl = document.getElementById('board');
const turnEl = document.getElementById('turn');
const statusEl = document.getElementById('status');
const playerEloEl = document.getElementById('playerElo');
const botEloEl = document.getElementById('botElo');
const moveListEl = document.getElementById('moveList');
const playerClockVal = document.getElementById('playerClockVal');
const botClockVal = document.getElementById('botClockVal');
const undoLeftEl = document.getElementById('undoLeft');

const menuModal = document.getElementById('menuModal');
const promoModal = document.getElementById('promoModal');
const resultModal = document.getElementById('resultModal');
const resultTitle = document.getElementById('resultTitle');
const resultMsg = document.getElementById('resultMsg');

/* ===========================
   Basic board helpers
   =========================== */
function idxToRC(i){ return {r: Math.floor(i/8), c: i%8}; }
function rcToIdx(r,c){ return r*8 + c; }
function inside(r,c){ return r>=0 && r<8 && c>=0 && c<8; }
function cloneBoard(b){ return b.map(row=> row.slice()); }
function pieceGlyph(p){
  if(!p) return '';
  return {'wP':'♙','wR':'♖','wN':'♘','wB':'♗','wQ':'♕','wK':'♔',
          'bP':'♟','bR':'♜','bN':'♞','bB':'♝','bQ':'♛','bK':'♚'}[p]||'';
}

/* ===========================
   Initialize board
   =========================== */
function resetBoard(){
  state.board = [
    ['bR','bN','bB','bQ','bK','bB','bN','bR'],
    ['bP','bP','bP','bP','bP','bP','bP','bP'],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['wP','wP','wP','wP','wP','wP','wP','wP'],
    ['wR','wN','wB','wQ','wK','wB','wN','wR']
  ];
  state.whiteToMove = true;
  state.history = [];
  state.selected = null;
  state.legalMoves = [];
  state.movesSAN = [];
  state.undoLeft = 3;
  updateUndo();
}

/* ===========================
   Move generation (basic rules incl promotion)
   =========================== */
function shouldPromote(r, side){ return (side==='w'&&r===0)||(side==='b'&&r===7); }

function generatePieceMoves(board, r,c, p){
  const side = p[0], piece = p[1], moves = [], forward = (side==='w')?-1:1, enemy = side==='w'?'b':'w';
  if(piece==='P'){
    const r1 = r+forward;
    if(inside(r1,c) && !board[r1][c]) moves.push({from:rcToIdx(r,c), to:rcToIdx(r1,c), promo:shouldPromote(r1,side)});
    const startRank = side==='w'?6:1;
    if(r===startRank && !board[r+forward][c] && !board[r+2*forward][c]) moves.push({from:rcToIdx(r,c), to:rcToIdx(r+2*forward,c)});
    for(const dc of [-1,1]){
      const cc = c+dc;
      if(inside(r1,cc) && board[r1][cc] && board[r1][cc][0]===enemy) moves.push({from:rcToIdx(r,c), to:rcToIdx(r1,cc), promo:shouldPromote(r1,side)});
    }
  }
  if(piece==='N'){
    const deltas=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
    deltas.forEach(d=>{ const rr=r+d[0], cc=c+d[1]; if(!inside(rr,cc)) return; if(!board[rr][cc]||board[rr][cc][0]!==side) moves.push({from:rcToIdx(r,c), to:rcToIdx(rr,cc)}); });
  }
  if(piece==='B'||piece==='R'||piece==='Q'){
    const dirs = [];
    if(piece==='B'||piece==='Q') dirs.push(...[[-1,-1],[-1,1],[1,-1],[1,1]]);
    if(piece==='R'||piece==='Q') dirs.push(...[[-1,0],[1,0],[0,-1],[0,1]]);
    dirs.forEach(d=>{
      let rr=r+d[0], cc=c+d[1];
      while(inside(rr,cc)){
        if(!board[rr][cc]) moves.push({from:rcToIdx(r,c), to:rcToIdx(rr,cc)});
        else { if(board[rr][cc][0]!==side) moves.push({from:rcToIdx(r,c), to:rcToIdx(rr,cc)}); break; }
        rr+=d[0]; cc+=d[1];
      }
    });
  }
  if(piece==='K'){
    for(let dr=-1;dr<=1;dr++) for(let dc=-1;dc<=1;dc++){ if(dr===0&&dc===0) continue; const rr=r+dr, cc=c+dc; if(!inside(rr,cc)) continue; if(!board[rr][cc]||board[rr][cc][0]!==side) moves.push({from:rcToIdx(r,c), to:rcToIdx(rr,cc)}); }
  }
  return moves;
}
function generateAllMoves(board, whiteToMove){
  const moves=[];
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(!p) continue;
    const isWhite = p[0]==='w';
    if(isWhite !== whiteToMove) continue;
    moves.push(...generatePieceMoves(board, r,c, p));
  }
  return moves;
}

/* ===========================
   Make / unmake move
   =========================== */
function makeMove(board, move){
  const f = idxToRC(move.from), t = idxToRC(move.to);
  const piece = board[f.r][f.c];
  const captured = board[t.r][t.c];
  board[t.r][t.c] = piece;
  board[f.r][f.c] = '';
  if(move.promo){ board[t.r][t.c] = piece[0] + move.promo; } // promo piece like 'wQ'
  return captured;
}
function unmakeMove(board, move, captured){
  const f = idxToRC(move.from), t = idxToRC(move.to);
  const moved = board[t.r][t.c];
  // if promoted, moved may be e.g. 'wQ' but original was pawn
  const origPiece = moved && moved[1] ? (moved[1] === move.promo ? 'P' : moved[1]) : (moved ? moved[1] : undefined);
  board[f.r][f.c] = moved ? moved[0] + (origPiece || moved[1]) : '';
  board[t.r][t.c] = captured || '';
}

/* ===========================
   In-check detection & legal moves
   =========================== */
function findKing(board, colorChar){
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){ const p = board[r][c]; if(p && p[0]===colorChar && p[1]==='K') return {r,c}; }
  return null;
}
function isSquareAttacked(board, r,c, byColorChar){
  for(let rr=0;rr<8;rr++) for(let cc=0;cc<8;cc++){
    const p = board[rr][cc];
    if(!p || p[0] !== byColorChar) continue;
    const pmoves = generatePieceMoves(board, rr,cc, p);
    if(pmoves.some(m => m.to === rcToIdx(r,c))) return true;
  }
  return false;
}
function inCheck(board, whiteToMove){
  const king = findKing(board, whiteToMove ? 'w' : 'b');
  if(!king) return true;
  return isSquareAttacked(board, king.r, king.c, whiteToMove ? 'b' : 'w');
}
function genLegalMoves(board, whiteToMove){
  const pseudo = generateAllMoves(board, whiteToMove);
  const legal = [];
  for(const m of pseudo){
    const bb = cloneBoard(board);
    const captured = makeMove(bb, m);
    if(!inCheck(bb, whiteToMove)) legal.push(m);
  }
  return legal;
}
function gameStatus(board, whiteToMove){
  const legal = genLegalMoves(board, whiteToMove);
  if(legal.length === 0){
    if(inCheck(board, whiteToMove)) return whiteToMove ? 'black_mate':'white_mate';
    return 'stalemate';
  }
  return 'playing';
}

/* ===========================
   Evaluation
   =========================== */
const PIECE_VALUE = { 'P':100, 'N':320, 'B':330, 'R':500, 'Q':900, 'K':20000 };
function evaluateBoard(board){
  let score = 0;
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(!p) continue;
    const val = PIECE_VALUE[p[1]] || 0;
    score += (p[0]==='w') ? val : -val;
  }
  // center control bonus
  const centers = [[3,3],[3,4],[4,3],[4,4]];
  centers.forEach(([r,c]) => { const p = board[r][c]; if(p) score += (p[0]==='w')?20:-20; });
  // mobility bonus (simple)
  const wmob = genLegalMoves(board, true).length;
  const bmob = genLegalMoves(board, false).length;
  score += (wmob - bmob) * 5;
  return score;
}

/* ===========================
   Minimax + alpha-beta
   =========================== */
function minimax(board, depth, alpha, beta, whiteToMove){
  const status = gameStatus(board, whiteToMove);
  if(status !== 'playing' || depth === 0){
    if(status === 'white_mate') return {score:-999999};
    if(status === 'black_mate') return {score:999999};
    if(status === 'stalemate') return {score:0};
    return {score: evaluateBoard(board)};
  }
  const legal = genLegalMoves(board, whiteToMove);
  let bestMove = null;
  if(whiteToMove){
    let maxEval = -Infinity;
    for(const m of legal){
      const captured = makeMove(board, m);
      const res = minimax(board, depth-1, alpha, beta, false);
      unmakeMove(board, m, captured);
      if(res.score > maxEval){ maxEval = res.score; bestMove = m; }
      alpha = Math.max(alpha, res.score);
      if(beta <= alpha) break;
    }
    return {score: maxEval, move: bestMove};
  } else {
    let minEval = Infinity;
    for(const m of legal){
      const captured = makeMove(board, m);
      const res = minimax(board, depth-1, alpha, beta, true);
      unmakeMove(board, m, captured);
      if(res.score < minEval){ minEval = res.score; bestMove = m; }
      beta = Math.min(beta, res.score);
      if(beta <= alpha) break;
    }
    return {score: minEval, move: bestMove};
  }
}

/* ===========================
   AI wrapper
   =========================== */
function aiMove(){
  if(!state.playing) return;
  const aiIsWhite = (state.aiColor === 'white');
  if(state.whiteToMove !== aiIsWhite) return;
  // use a small delay to make UI feel natural
  setTimeout(()=>{
    const clone = cloneBoard(state.board);
    const res = minimax(clone, state.depth, -Infinity, Infinity, state.whiteToMove);
    const mv = res.move;
    if(!mv){
      // no move
      checkAfterMove();
      return;
    }
    const captured = makeMove(state.board, mv);
    state.history.push({move:mv, captured, prevWhite: state.whiteToMove});
    state.whiteToMove = !state.whiteToMove;
    pushSAN(mv);
    renderBoard();
    checkAfterMove();
  }, 120);
}

/* ===========================
   SAN (simple) & move list
   =========================== */
function sqName(idx){ const rc = idxToRC(idx); return 'abcdefgh'[rc.c] + (8-rc.r); }
function pushSAN(move){
  const to = sqName(move.to);
  const piece = state.board[idxToRC(move.to).r][idxToRC(move.to).c];
  const letter = piece && piece[1] !== 'P' ? piece[1] : '';
  state.movesSAN.push(letter + to);
  renderMoveList();
}
function renderMoveList(){
  moveListEl.innerHTML = state.movesSAN.map((m,i)=> `<div>${i+1}. ${m}</div>`).join('');
}

/* ===========================
   UI interactions
   =========================== */
function renderBoard(){
  boardEl.innerHTML = '';
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const idx = rcToIdx(r,c);
      const cell = document.createElement('div');
      const light = (r+c)%2===0;
      cell.className = 'cell ' + (light ? 'light' : 'dark');
      cell.dataset.idx = idx;
      const p = state.board[r][c];
      cell.innerHTML = pieceGlyph(p);
      if(state.selected === idx) cell.classList.add('highlight');
      if(state.legalMoves.some(m=> m.to === idx)) cell.style.outline = '2px solid rgba(43,212,123,0.22)';
      cell.addEventListener('click', ()=> onCellClick(idx));
      boardEl.appendChild(cell);
    }
  }
  updateStatus();
  renderMoveList();
}
function updateStatus(){
  turnEl.textContent = state.whiteToMove ? 'White' : 'Black';
  statusEl.textContent = state.playing ? 'Playing' : 'Idle';
  playerEloEl.textContent = state.playerElo;
  botEloEl.textContent = state.botElo;
  updateUndo();
}
function updateUndo(){ undoLeftEl.textContent = state.undoLeft; }

/* Click handling */
function onCellClick(idx){
  if(!state.playing) return;
  const rci = idxToRC(idx);
  const p = state.board[rci.r][rci.c];
  const playerIsWhite = (state.playerColor === 'white');
  const playerTurn = (state.whiteToMove && playerIsWhite) || (!state.whiteToMove && !playerIsWhite);
  if(!playerTurn) return;
  if(p && ((state.whiteToMove && p[0]==='w') || (!state.whiteToMove && p[0]==='b'))){
    state.selected = idx;
    state.legalMoves = genLegalMoves(state.board, state.whiteToMove).filter(m => m.from === idx);
    renderBoard();
    return;
  }
  if(state.selected !== null){
    const moves = state.legalMoves || [];
    const mv = moves.find(m => m.to === idx);
    if(mv){
      if(mv.promo){
        pendingPromo = {move: mv};
        promoModal.style.display = 'flex';
        return;
      }
      const captured = makeMove(state.board, mv);
      state.history.push({move: mv, captured, prevWhite: state.whiteToMove});
      state.whiteToMove = !state.whiteToMove;
      pushSAN(mv);
      renderBoard();
      checkAfterMove();
      if(state.playing && ((state.aiColor==='black' && !state.whiteToMove) || (state.aiColor==='white' && state.whiteToMove))){
        aiMove();
      }
      return;
    } else {
      state.selected = null; state.legalMoves = [];
      renderBoard();
    }
  }
}
let pendingPromo = null;
document.querySelectorAll('.promo').forEach(b => b.addEventListener('click', (e) => {
  const piece = e.currentTarget.dataset.piece;
  if(!pendingPromo) return;
  pendingPromo.move.promo = piece;
  const m = pendingPromo.move;
  const captured = makeMove(state.board, m);
  state.history.push({move: m, captured, prevWhite: state.whiteToMove});
  state.whiteToMove = !state.whiteToMove;
  pendingPromo = null;
  promoModal.style.display = 'none';
  pushSAN(m);
  renderBoard();
  checkAfterMove();
  if(state.playing) aiMove();
}));

/* ===========================
   After-move checks (endgame)
   =========================== */
function checkAfterMove(){
  const status = gameStatus(state.board, state.whiteToMove);
  if(status === 'playing'){ updateStatus(); return; }
  state.playing = false;
  stopClocks();
  renderBoard();
  if(status === 'white_mate' || status === 'black_mate'){
    const winner = (status === 'white_mate') ? 'black' : 'white';
    const result = (winner === state.playerColor) ? 'win' : 'lose';
    handleResult(result, winner);
  } else if(status === 'stalemate'){
    handleResult('draw', null);
  }
}

/* ===========================
   Result / ELO
   =========================== */
const ELO_KEY = 'minichess_elo_v3';
function loadElo(){ try{ return JSON.parse(localStorage.getItem(ELO_KEY)||'{}'); }catch(e){ return {}; } }
function saveElo(){ const o = loadElo(); o.player = state.playerElo; o.bot = state.botElo; localStorage.setItem(ELO_KEY, JSON.stringify(o)); updateStatus(); }
function initElo(defaultVal){ const o = loadElo(); state.playerElo = o.player || Number(defaultVal) || 800; state.botElo = o.bot || (state.playerElo + 200); updateStatus(); }

function handleResult(result, winnerColor){
  if(result === 'win'){ state.playerElo = Number(state.playerElo) + 5; resultTitle.textContent = 'YOU WIN — CHECKMATE!'; }
  else if(result === 'lose'){ resultTitle.textContent = 'YOU LOSE — CHECKMATED'; }
  else { state.playerElo = Number(state.playerElo) + 1; resultTitle.textContent = 'DRAW — STALEMATE'; }
  saveElo();
  resultMsg.textContent = `Result: ${result.toUpperCase()}`;
  resultModal.style.display = 'flex';
}

/* ===========================
   Clocks (simple)
   =========================== */
function initClocks(mode){
  stopClocks();
  if(mode === 'none'){ state.playerClock = 0; state.botClock = 0; playerClockVal.textContent = '--:--'; botClockVal.textContent = '--:--'; return; }
  if(mode === 'blitz'){ state.playerClock = 180; state.botClock = 180; }
  if(mode === 'hyper'){ state.playerClock = 30; state.botClock = 30; }
  state.clockInterval = setInterval(()=>{
    if(!state.playing) return;
    const playerTurn = (state.whiteToMove === (state.playerColor === 'white'));
    if(playerTurn) state.playerClock = Math.max(0, +(state.playerClock - 0.1).toFixed(1));
    else state.botClock = Math.max(0, +(state.botClock - 0.1).toFixed(1));
    playerClockVal.textContent = formatClock(state.playerClock);
    botClockVal.textContent = formatClock(state.botClock);
    if(state.playerClock <= 0 || state.botClock <= 0){
      handleClockTimeout(state.playerClock <= 0 ? 'player' : 'bot');
    }
  }, 100);
}
function formatClock(s){ if(s <= 0) return '0:00'; const mm = Math.floor(s/60); const ss = Math.floor(s%60).toString().padStart(2,'0'); return `${mm}:${ss}`; }
function handleClockTimeout(who){ stopClocks(); state.playing = false; if(who === 'player'){ handleResult('lose', state.aiColor); } else { state.playerElo = Number(state.playerElo) + 5; saveElo(); handleResult('win', state.playerColor); } }
function stopClocks(){ clearInterval(state.clockInterval); state.clockInterval = null; }

/* ===========================
   Undo / Resign / Restart
   =========================== */
document.getElementById('undoBtn').onclick = ()=>{
  if(state.undoLeft <= 0){ alert('Undo limit reached'); return; }
  if(state.history.length === 0) return;
  const last = state.history.pop();
  unmakeMove(state.board, last.move, last.captured);
  state.whiteToMove = last.prevWhite;
  state.undoLeft--;
  renderBoard();
  updateStatus();
};
document.getElementById('resignBtn').onclick = ()=>{
  if(!confirm('Resign?')) return;
  state.playing = false;
  handleResult('lose', state.aiColor);
};
document.getElementById('restartBtn').onclick = ()=>{
  if(!confirm('Restart match?')) return;
  resetBoard();
  renderBoard();
  updateStatus();
};

/* ===========================
   New match wiring
   =========================== */
document.getElementById('openMenu').onclick = ()=> menuModal.style.display = 'flex';
document.getElementById('mmCancel').onclick = ()=> menuModal.style.display = 'none';
document.getElementById('mmStart').onclick = ()=>{
  const startElo = Number(document.getElementById('mmElo').value);
  const diff = document.getElementById('mmDifficulty').value;
  const time = document.getElementById('mmTime').value;
  const side = document.getElementById('mmSide').value;
  menuModal.style.display = 'none';
  startNewMatch({playerElo:startElo, difficulty:diff, timeControl:time, side});
};

function startNewMatch(opts){
  resetBoard();
  state.playerElo = opts.playerElo || 800;
  state.botElo = state.playerElo + 200;
  state.timeControl = opts.timeControl || 'none';
  state.playerColor = opts.side || 'white';
  state.aiColor = (state.playerColor === 'white') ? 'black' : 'white';
  state.depth = (opts.difficulty === 'novice') ? 1 : (opts.difficulty === 'casual') ? 2 : (opts.difficulty === 'strong') ? 3 : 4;
  state.playing = true;
  state.whiteToMove = true;
  state.history = [];
  state.movesSAN = [];
  state.undoLeft = 3;
  initClocks(state.timeControl);
  renderBoard();
  updateStatus();
  saveElo();
  if(state.aiColor === 'white') aiMove();
}

/* ===========================
   Render and boot
   =========================== */
function renderMoveList(){ moveListEl.innerHTML = state.movesSAN.map((m,i)=> `<div>${i+1}. ${m}</div>`).join(''); }
function renderBoard(){ boardEl.innerHTML=''; for(let r=0;r<8;r++){ for(let c=0;c<8;c++){ const idx = rcToIdx(r,c); const cell = document.createElement('div'); const light = (r+c)%2===0; cell.className = 'cell ' + (light ? 'light' : 'dark'); cell.dataset.idx = idx; const p = state.board[r][c]; cell.innerHTML = pieceGlyph(p); if(state.selected === idx) cell.classList.add('highlight'); if(state.legalMoves.some(m=> m.to === idx)) cell.style.outline = '2px solid rgba(43,212,123,0.22)'; cell.addEventListener('click', ()=> onCellClick(idx)); boardEl.appendChild(cell); } } updateStatus(); renderMoveList(); }
function updateStatus(){ turnEl.textContent = state.whiteToMove ? 'White' : 'Black'; statusEl.textContent = state.playing ? 'Playing' : 'Idle'; playerEloEl.textContent = state.playerElo; botEloEl.textContent = state.botElo; updateUndo(); }

resetBoard();
initElo(800);
renderBoard();
updateStatus();

/* show personal elo */
document.getElementById('showPB').onclick = ()=>{ const o = loadElo(); alert(`Player Elo: ${o.player||'-'}\nBot Elo: ${o.bot||'-'}`); };

/* close overlays by clicking outside */
document.querySelectorAll('.overlay').forEach(ov => ov.addEventListener('click', e=>{ if(e.target===ov) ov.style.display='none'; }));
document.getElementById('resultOk').onclick = ()=> { resultModal.style.display='none'; };

/* small helper for rc conversion in many places */
function idxToRC(i){ return {r: Math.floor(i/8), c: i%8}; }
function rcToIdx(r,c){ return r*8 + c; }
